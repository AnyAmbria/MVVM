//
//  MainStep.swift
//  RickMoya
//
//  Created by any.pinheiro on 04/02/19.
//  Copyright © 2019 any.pinheiro. All rights reserved.
//

import RxFlow

enum MainStep: Step {
    case listCharacter
}
