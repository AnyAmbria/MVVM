//
//  StartupStep.swift
//  RickMoya
//
//  Created by any.pinheiro on 01/02/19.
//  Copyright © 2019 any.pinheiro. All rights reserved.
//

import RxFlow

enum StartupStep : Step {
    case selectInitialFlow
}
