//
//  ViewController.swift
//  RickMoya
//
//  Created by any.pinheiro on 01/02/19.
//  Copyright © 2019 any.pinheiro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

